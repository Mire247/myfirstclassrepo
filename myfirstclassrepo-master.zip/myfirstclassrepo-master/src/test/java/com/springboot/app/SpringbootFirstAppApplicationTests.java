package com.springboot.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootFirstAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
